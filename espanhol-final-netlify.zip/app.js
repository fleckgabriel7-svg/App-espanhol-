const dom = {
    quadro: document.getElementById('quadroImagem'), 
    painel: document.getElementById('painelBotoes'),
    frase: document.getElementById('fraseAlvo'),
    pt: document.getElementById('traducaoPt'),
    btnGravar: document.getElementById('btnGravar'),
    lblGravar: document.getElementById('lbl-gravar'),
    btnOuvir: document.getElementById('btnOuvir'),
    status: document.getElementById('status'),
    resultado: document.getElementById('resultadoTela'),
    tagLocal: document.getElementById('tagLocal')
};

let indiceAtual = 0;
let fraseAtualEspanhol = ""; 
let progressoSalvo = JSON.parse(localStorage.getItem('progressoEspanholPro')) || [];

// Sistema de voz
dom.btnOuvir.addEventListener('click', () => {
    initAudio();
    if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel(); 
        const robo = new SpeechSynthesisUtterance(fraseAtualEspanhol);
        robo.lang = 'es-ES'; 
        robo.rate = 0.85; 
        window.speechSynthesis.speak(robo);
    }
});

function inicializarApp() {
    for (let i = 0; i < listaDeFrases.length; i++) {
        let botao = document.createElement("button");
        botao.innerText = (i + 1).toString().padStart(3, '0');
        botao.className = "botao-numero";
        botao.id = "btn-" + i;
        if (progressoSalvo.includes(i)) botao.classList.add('concluido');
        botao.addEventListener("click", () => mudarFrase(i));
        dom.painel.appendChild(botao);
    }
    mudarFrase(progressoSalvo.length > 0 ? Math.min(Math.max(...progressoSalvo) + 1, listaDeFrases.length - 1) : 0);
}

function mudarFrase(indice) {
    indiceAtual = indice;
    fraseAtualEspanhol = listaDeFrases[indice].es;
    dom.frase.innerText = fraseAtualEspanhol;
    dom.pt.innerText = listaDeFrases[indice].pt;
    
    document.querySelectorAll('.botao-numero').forEach(b => b.classList.remove('ativo'));
    const btn = document.getElementById("btn-" + indice);
    if(btn) {
        btn.classList.add('ativo');
        btn.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    dom.resultado.innerHTML = "";
    dom.status.innerText = "Presione 'Hablar' y repita la frase.";
    dom.status.style.color = "var(--text-secondary)";

    const imgSorteada = imagensDeFundo[Math.floor(Math.random() * imagensDeFundo.length)];
    dom.quadro.style.backgroundImage = `url('${imgSorteada.url}')`;
    dom.tagLocal.innerText = `📍 ${imgSorteada.nome}`;
}

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

if (SpeechRecognition) {
    const recognition = new SpeechRecognition();
    recognition.lang = 'es-ES'; 
    recognition.interimResults = false;

    dom.btnGravar.addEventListener('click', () => {
        initAudio();
        try { recognition.start(); } catch(e) { }
    });

    recognition.onstart = () => {
        dom.btnGravar.classList.add('gravando');
        dom.lblGravar.innerText = "Escuchando...";
        dom.status.innerText = "🎤 Sistema activado. Puede hablar...";
        dom.status.style.color = "var(--accent-blue)"; 
        dom.resultado.innerHTML = "";
    };

    recognition.onend = () => {
        dom.btnGravar.classList.remove('gravando');
        dom.lblGravar.innerText = "Hablar";
    };

    recognition.onresult = (evento) => {
        const fraseFalada = evento.results[0][0].transcript;
        dom.status.innerText = `Usted dijo: "${fraseFalada}"`;
        dom.status.style.color = "var(--text-secondary)";
        analisarPronuncia(fraseAtualEspanhol, fraseFalada);
    };

    recognition.onerror = (evento) => {
        dom.status.innerText = "❌ Error de micrófono. Intente de nuevo.";
        dom.status.style.color = "var(--error-red)";
    };

} else {
    dom.status.innerText = "⚠️ Su navegador no soporta reconocimiento de voz.";
    dom.btnGravar.style.display = "none";
}

function analisarPronuncia(alvo, falada) {
    const limpar = (t) => t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[.,!?¡¿]/g, "").trim();
    
    const palabrasAlvo = limpar(alvo).split(" ");
    const palabrasFaladas = limpar(falada).split(" ");

    let htmlFinal = "";
    let acertouTudo = true;

    for (let i = 0; i < palabrasAlvo.length; i++) {
        let pCerta = palabrasAlvo[i];
        let pDita = palabrasFaladas[i] || ""; 

        if (pCerta === pDita) {
            htmlFinal += `<span class="correto">${listaDeFrases[indiceAtual].es.split(" ")[i]} </span>`;
        } else {
            htmlFinal += `<span class="errado">${listaDeFrases[indiceAtual].es.split(" ")[i]} </span>`;
            acertouTudo = false;
        }
    }

    dom.resultado.innerHTML = htmlFinal;

    if (acertouTudo) {
        tocarSomAcerto();
        dom.status.innerText = "🎉 ¡Pronunciación Perfecta! Gold Star!";
        dom.status.style.color = "var(--success-green)";
        
        if (!progressoSalvo.includes(indiceAtual)) {
            progressoSalvo.push(indiceAtual);
            localStorage.setItem('progressoEspanholPro', JSON.stringify(progressoSalvo));
            document.getElementById("btn-" + indiceAtual).classList.add('concluido');
        }
        
        setTimeout(() => {
            if(indiceAtual < listaDeFrases.length - 1) {
                mudarFrase(indiceAtual + 1);
            } else {
                dom.status.innerText = "🏆 ¡FELICIDADES! ¡Completó todo!";
            }
        }, 1800);
    } else {
        tocarSomErro();
        dom.status.innerText = "❌ Algunas palabras fallaron. ¡Inténtelo de nuevo!";
        dom.status.style.color = "var(--error-red)";
    }
}

inicializarApp();
