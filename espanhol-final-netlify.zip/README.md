# 🇪🇸 Espanhol Pro - App Gamificado

Aprenda espanhol com sons de jogo e reconhecimento de voz!

## 🚀 Deploy Netlify

1. https://app.netlify.com/drop
2. Arraste o ZIP
3. Pronto!

## ✨ Funcionalidades

- 🎤 Reconhecimento de voz (es-ES)
- 🔊 Pronúncia nativa
- 🎮 **Sons de jogo**: Acerto = moeda, Erro = buzzer
- 📸 Imagens Unsplash de alta qualidade
- 100 frases essenciais
- 📊 Progresso salvo
